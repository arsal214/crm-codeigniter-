<!--<link rel="stylesheet" href="<?=site_url()?>/modules/sales_marketing/assets/css/datatables.css"> -->
<table class="table dt-table" data-order-col="1" data-order-type="asc" id="searched_reminder_table" data-page-length='10' style="font-size:0.9em">
    <thead>
        <tr>
            <th class="">Customer</th>    
            <th class="">Employee</th>
            <th class="">Title</th>
            <th class="">DateTime</th>
            <th class="">IN</th>
        </tr>
    </thead>
    <tbody>
        <?php
            if($reminder_data){
                foreach($reminder_data as $key => $val){
                    $client_data = get_client($val['customer_id']);
                    $client_name = "";
                    if($client_data){
                        $client_name = $client_data->company; 
                    }
                    $date = $val['date'];
            ?>
                    <tr>
                        <td><?=$client_name?></td>
                        <td><?=get_staff_full_name($val['staff'])?></td>
                        <td><?=$val['title']?></td>
                        <td><?=$val['date']?></td>
                        <td><?=timeRemainString($date)?></td>
                    </tr>            
            <?php
                }
            }
        ?>
    </tbody>
</table>  

<script type="text/javascript" id="" src="<?=site_url()?>/assets/plugins/datatables/datatables.min.js?v=3.1.6"></script>
<script>   
$(document).ready(function () {  

    //app.lang.datatables = {"emptyTable":"No entries found","info":"Showing _START_ to _END_ of _TOTAL_ entries","infoEmpty":"Showing 0 to 0 of 0 entries","infoFiltered":"(filtered from _MAX_ total entries)","lengthMenu":"_MENU_","loadingRecords":"Loading...","processing":"<div class=\"dt-loader\"><\/div>","search":"<div class=\"input-group\"><span class=\"input-group-addon\"><span class=\"fa fa-search\"><\/span><\/span>","searchPlaceholder":"Search...","zeroRecords":"No matching records found","paginate":{"first":"First","last":"Last","next":"Next","previous":"Previous"},"aria":{"sortAscending":" activate to sort column ascending","sortDescending":" activate to sort column descending"}}; 
    $('#searched_reminder_table').DataTable({
        //dom: 'Bfrtip',
        paging: true,
        searching: true,
    });
    
});

</script>