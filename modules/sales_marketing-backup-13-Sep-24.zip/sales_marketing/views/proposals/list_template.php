<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="col-md-12">
    
    <div class="row">
        <div class="col-md-12 small-table-right-col">
            <div id="proposal" class="">
            </div>
        </div>
    </div>
</div>