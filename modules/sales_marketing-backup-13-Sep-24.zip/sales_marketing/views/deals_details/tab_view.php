<?php
$this->load->view('deals_details/tabs');
?>