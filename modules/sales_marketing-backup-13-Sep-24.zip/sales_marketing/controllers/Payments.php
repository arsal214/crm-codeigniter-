<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * @property Invoices_model $invoices_model
 * @property Payments_model $payments_model
 */
class Payments extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('payments_model');
    }

    /* Delete payment */
    public function delete($id="",$sam_id="")
    {
        if (staff_cant('delete', 'payments')) {
            access_denied('Delete Payment');
        }
        if (!$id) {                                               
            redirect(admin_url(SAM_MODULE.'/details/'.$sam_id.'/payments'));
        }
        $response = $this->payments_model->delete($id);
        if ($response == true) {
            set_alert('success', _l('deleted', _l('payment')));
        } else {
            set_alert('warning', _l('problem_deleting', _l('payment_lowercase')));
        }                                     
        redirect(admin_url(SAM_MODULE.'/details/'.$sam_id.'/payments'));
    }
}
