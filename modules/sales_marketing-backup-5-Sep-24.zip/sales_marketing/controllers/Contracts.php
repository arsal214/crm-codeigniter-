<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Contracts extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('contracts_model');
        $this->load->model('sam_model');
    }

    /* Edit contract or add new contract */
    public function contract($id = '0',$sam_id = '')
    {
        $cond = array('id' => $sam_id);
        $sam_rec = $this->sam_model->getAllRecords("tbl_sam","*",$cond);
        $customer_id = "";
        if($sam_rec){
            $sam_rec = $sam_rec[0];
            $customer_id = $sam_rec['rel_id'];
            //print_r(get_client($customer_id)); exit;
        } 
        if ($this->input->post()) { 
            
            if ($id == '' || $id == 0) {
                
                if (staff_cant('create', 'contracts')) {
                    access_denied('contracts');
                }
                
                $post_data = $this->input->post();
                $post_data['sam_id'] = $sam_id;
                //echo "<pre>"; print_r($post_data); exit;
                $id = $this->contracts_model->add($post_data);
                if ($id) {
                    add_activity_transactions($sam_id,'added new contract');
                    $success = true;
                    $msg = _l('added_successfully', _l('contract'));
                    //set_alert('success', _l('added_successfully', _l('contract')));
                
                }
                else{
                    $success = false;
                    $msg = "Contract not added";
                }
                echo json_encode([
                    'success'           => $success,
                    'message'           => $msg,                                                             
                ]);
                die;
            } 
            else {   
                if (staff_cant('edit', 'contracts')) {
                    access_denied('contracts');
                }
                 
                $contract = $this->contracts_model->get($id);
                $data     = $this->input->post();

                if ($contract->signed == 1) {
                    unset($data['contract_value'],$data['clientid'], $data['datestart'], $data['dateend']);
                }

                $success = $this->contracts_model->update($data, $id);
                if ($success) {
                    set_alert('success', _l('updated_successfully', _l('contract')));
                }
                redirect(admin_url('contracts/contract/' . $id));
            }
        }
        if ($id == '' || $id == 0) {
            $title = _l('add_new', _l('contract_lowercase'));
        } else {
            $data['contract']                 = $this->contracts_model->get($id, [], true);
            $data['contract_renewal_history'] = $this->contracts_model->get_contract_renewal_history($id);
            $data['totalNotes']               = total_rows(db_prefix() . 'notes', ['rel_id' => $id, 'rel_type' => 'contract']);
            if (!$data['contract'] || (staff_cant('view', 'contracts') && $data['contract']->addedfrom != get_staff_user_id())) {
                blank_page(_l('contract_not_found'));
            }

            $data['contract_merge_fields'] = $this->app_merge_fields->get_flat('contract', ['other', 'client'], '{email_signature}');

            $title = $data['contract']->subject;

            $data = array_merge($data, prepare_mail_preview_data('contract_send_to_customer', $data['contract']->client));
        }
        $data['sam_id'] = $sam_id;
        $data['customer_id'] = $customer_id;
        $this->load->model('currencies_model');
        $data['base_currency'] = $this->currencies_model->get_base_currency();
        $data['types']         = $this->contracts_model->get_contract_types();
        //echo "<pre>"; print_r($data['types']); exit;
        $data['title']         = $title;
        $data['bodyclass']     = 'contract';
        $this->load->view(SAM_MODULE.'/contracts/contract', $data);
    }
    
    /* Delete contract from database */
    public function delete($id='',$sam_id='')
    {
        if (staff_cant('delete', 'contracts')) {
            access_denied('contracts');
        }
        if (!$id) {
            //redirect(admin_url('contracts'));
            redirect(admin_url(SAM_MODULE.'/details/'.$sam_id.'/contracts'));
        }
        $response = $this->contracts_model->delete($id);
        if ($response == true) {
            set_alert('success', _l('deleted', _l('contract')));
        } else {
            set_alert('warning', _l('problem_deleting', _l('contract_lowercase')));
        }
        
        redirect(admin_url(SAM_MODULE.'/details/'.$sam_id.'/contracts'));
    }

}
