<?php                               

defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard_model extends App_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('projects_model');
        $this->load->model('staff_model');
    }
    
    public function get_pipelines(){
        $res = $this->db->select('*')->get('tbl_sam_pipelines')->result_array();
        if($res){
            return $res;
        }
        else{
            return false;
        }
    }
    
    public function getPipelineNameById($id=0){
        $res = $this->db->select('pipeline_name as name')->where('pipeline_id',$id)->get('tbl_sam_pipelines')->row();
        if($res){
            return $res->name;
        }
        else{
            return false;
        }
    }
    
    public function get_all_staff(){
        $res = $this->db->select("CONCAT(firstname,' ',lastname) as fullname, staffid")->get('tblstaff')->result_array();
        if($res){
            return $res;
        }
        else{
            return false;
        }
    }
    
    public function get_staff_timesheets($post_data=array(),$default=false){
        if($default){
            $userid_cond = 1;
            if(!is_admin()){
                $userid_cond = "t.staff_id=".get_staff_user_id();
            }
            $beginThisMonth = date('Y-m-01 00:00:00');
            $endThisMonth   = date('Y-m-t 23:59:59');    
            $where = 'WHERE '.$userid_cond.' AND t.deleted=0 AND t.start_time BETWEEN ' . strtotime($beginThisMonth) . ' AND ' . strtotime($endThisMonth);
            $query = '
                SELECT t.staff_id, t.pipeline_id, sum(time_spent) as total_time_spent 
                FROM tbl_sam_taskstimers as t
                JOIN tbl_sam as t2 on t.sam_id = t2.id
                '."$where".'
                group by t.staff_id
            
            ';
            //echo $query; exit;
            $result = $this->db->query($query)->result_array();
            if($result){
                //echo "<pre>"; print_r($result);exit;
                return $result;
            }
            else{
                return false;
            }
        }
        else{
            if(is_array($post_data)){
                $where = [];
                if(isset($post_data['staff_id']) && $post_data['staff_id']!=""){
                        $where = [
                            'AND t.staff_id=' . $this->db->escape_str($post_data['staff_id']),
                        ];
                }
                if(isset($post_data['pipeline_id']) && $post_data['pipeline_id']!=""){
                        $where = [
                            'AND t.pipeline_id=' . $this->db->escape_str($post_data['pipeline_id']),
                        ];
                }
                if(isset($post_data['range'])){
                    $range = $post_data['range'];
                    //today
                    if($range=='today'){
                        $beginOfDay = strtotime('midnight');
                        $endOfDay   = strtotime('tomorrow', $beginOfDay) - 1;
                        array_push($where, ' AND t.start_time BETWEEN ' . $beginOfDay . ' AND ' . $endOfDay);
                    }
                    //seven days
                    elseif($range=='last_seven_days'){
                        $beginThisWeek = date('Y-m-d 00:00:00', strtotime('-7 DAYS'));
                        $endThisWeek   = date('Y-m-d 23:59:59');
                        array_push($where, ' AND t.start_time BETWEEN ' . strtotime($beginThisWeek) . ' AND ' . strtotime($endThisWeek));
                    }
                    //this week
                    elseif($range=='this_week'){
                        $beginThisWeek = date('Y-m-d 00:00:00', strtotime('monday this week'));
                        $endThisWeek   = date('Y-m-d 23:59:59', strtotime('sunday this week'));
                        array_push($where, ' AND t.start_time BETWEEN ' . strtotime($beginThisWeek) . ' AND ' . strtotime($endThisWeek));
                    }
                    //last week
                    elseif($range=='last_week'){
                        $beginLastWeek = date('Y-m-d 00:00:00', strtotime('monday last week'));
                        $endLastWeek   = date('Y-m-d 23:59:59', strtotime('sunday last week'));
                        array_push($where, ' AND t.start_time BETWEEN ' . strtotime($beginLastWeek) . ' AND ' . strtotime($endLastWeek));
                    }
                    //this month
                    elseif($range=='this_month'){
                        $beginThisMonth = date('Y-m-01 00:00:00');
                        $endThisMonth   = date('Y-m-t 23:59:59');
                        array_push($where, ' AND t.start_time BETWEEN ' . strtotime($beginThisMonth) . ' AND ' . strtotime($endThisMonth));
                    }
                    //last month
                    elseif($range=='last_month'){
                        $beginLastMonth = date('Y-m-01 00:00:00', strtotime('-1 MONTH'));
                        $endLastMonth   = date('Y-m-t 23:59:59', strtotime('-1 MONTH'));
                        array_push($where, ' AND t.start_time BETWEEN ' . strtotime($beginLastMonth) . ' AND ' . strtotime($endLastMonth));
                    }
                    //this year
                    elseif($range=='this_year'){
                        $beginOfDay = date('Y-01-01 00:00:00');
                        $endOfDay   = date('Y-12-t 23:59:59');
                        array_push($where, ' AND t.start_time BETWEEN ' . strtotime($beginOfDay) . ' AND ' . strtotime($endOfDay));
                    }
                    //last year
                    elseif($range=='last_year'){
                        $beginOfDay = date('Y-01-01 00:00:00', strtotime('-1 YEAR'));
                        $endOfDay   = date('Y-12-t 23:59:59', strtotime('-1 YEAR'));
                        array_push($where, ' AND t.start_time BETWEEN ' . strtotime($beginOfDay) . ' AND ' . strtotime($endOfDay));
                    }
                    //search by periods
                    elseif($range=='period'){
                        $start_date = to_sql_date($post_data['periodfrom']);
                        $end_date   = to_sql_date($post_data['periodto']);
                        array_push($where, ' AND t.start_time BETWEEN ' . strtotime($start_date . ' 00:00:00') . ' AND ' . strtotime($end_date . ' 23:59:59'));
                    }
                    //all
                    elseif($range=='all'){
                        
                    }
                }
                
                //echo "<pre>"; print_r($where); exit;
                $where = implode(' ', $where);
                $where = trim($where);
                if (startsWith($where, 'AND') || startsWith($where, 'OR')) {
                    if (startsWith($where, 'OR')) {
                        $where = substr($where, 2);
                    } else {
                        $where = substr($where, 3);
                    }                
                }
                if($where!=''){
                    $where = 'WHERE t.deleted=0 AND ' . $where;    
                }
                else{
                    $where = 'WHERE t.deleted=0';
                }
                $query = '
                    SELECT t.staff_id, t.pipeline_id, sum(time_spent) as total_time_spent 
                    FROM tbl_sam_taskstimers as t
                    JOIN tbl_sam as t2 on t.sam_id = t2.id
                    '."$where".'
                    group by t.staff_id
                
                ';
                //echo $query; exit;
                $result = $this->db->query($query)->result_array();
                if($result){
                    //echo "<pre>"; print_r($result);exit;
                    return $result;
                }
                else{
                    return false;
                }
                
            }        
        }
    }
    
    public function get_leads_on_customer($post_data=array(),$default=false){
        if($default){
            $userid_cond = 1;
            if(!is_admin()){
                $userid_cond = "t.staff_id=".get_staff_user_id();
            }
            $beginThisMonth = date('Y-m-01');
            $endThisMonth   = date('Y-m-d');
            //array_push($where, ' AND t.t_date BETWEEN "' . $beginThisMonth . '" AND "' . $endThisMonth.'"');    
            $where = 'where '.$userid_cond.' AND t.t_date BETWEEN "' . $beginThisMonth . '" AND "' . $endThisMonth.'"';
            $query = '
                SELECT count(t.staff_id) as total_activities, t.sam_id, t.staff_id, t.pipeline_id 
                FROM tbl_sam_transactions as t
                JOIN tbl_sam as t2 on t.sam_id = t2.id                               
                '."$where".'
                group by t.staff_id
            
            ';
            //echo $query; exit;
            $result = $this->db->query($query)->result_array();
            if($result){
                //echo "<pre>"; print_r($result);exit;
                return $result;
            }
            else{
                return false;
            }
        }
        else{
            if(is_array($post_data)){
                $where = [];
                if(isset($post_data['staff_id']) && $post_data['staff_id']!=""){
                        $where = [
                            'AND t.staff_id=' . $this->db->escape_str($post_data['staff_id']),
                        ];
                }
                if(isset($post_data['range'])){
                    $range = $post_data['range'];
                    //today
                    if($range=='today'){
                        $beginOfDay = date('Y-m-d',strtotime('TODAY'));       
                        array_push($where, ' AND t.t_date="' . $beginOfDay.'"');
                    }
                    //seven days
                    elseif($range=='last_seven_days'){
                        $beginThisWeek = date('Y-m-d', strtotime('-7 DAYS'));
                        $endThisWeek   = date('Y-m-d');
                        array_push($where, ' AND t.t_date BETWEEN "' . $beginThisWeek . '" AND "' . $endThisWeek.'"');
                    }
                    //this week
                    elseif($range=='this_week'){
                        $beginThisWeek = date('Y-m-d', strtotime('monday this week'));
                        $endThisWeek   = date('Y-m-d', strtotime('sunday this week'));
                        array_push($where, ' AND t.t_date BETWEEN "' . $beginThisWeek . '" AND "' . $endThisWeek.'"');
                    }
                    //last week
                    elseif($range=='last_week'){
                        $beginLastWeek = date('Y-m-d', strtotime('monday last week'));
                        $endLastWeek   = date('Y-m-d', strtotime('sunday last week'));
                        array_push($where, ' AND t.t_date BETWEEN "' . $beginLastWeek . '" AND "' . $endLastWeek.'"');
                    }
                    //this month
                    elseif($range=='this_month'){
                        $beginThisMonth = date('Y-m-01');
                        $endThisMonth   = date('Y-m-d');
                        array_push($where, ' AND t.t_date BETWEEN "' . $beginThisMonth . '" AND "' . $endThisMonth.'"');
                    }
                    //last month
                    elseif($range=='last_month'){
                        $beginLastMonth = date('Y-m-01', strtotime('-1 MONTH'));
                        $endLastMonth   = date('Y-m-t', strtotime('-1 MONTH'));
                        array_push($where, ' AND t.t_date BETWEEN "' . $beginLastMonth . '" AND "' . $endLastMonth.'"');
                    }
                    //this year
                    elseif($range=='this_year'){
                        $beginOfDay = date('Y-01-01');
                        $endOfDay   = date('Y-12-31');
                        array_push($where, ' AND t.t_date BETWEEN "' . $beginOfDay . '" AND "' . $endOfDay.'"');
                    }
                    //last year
                    elseif($range=='last_year'){
                        $beginOfDay = date('Y-01-01', strtotime('-1 YEAR'));
                        $endOfDay   = date('Y-12-t', strtotime('-1 YEAR'));
                        array_push($where, ' AND t.t_date BETWEEN "' . $beginOfDay . '" AND "' . $endOfDay.'"');
                    }
                    //search by periods
                    elseif($range=='period'){
                        $start_date = to_sql_date($post_data['periodfrom']);
                        $end_date   = to_sql_date($post_data['periodto']);
                        array_push($where, ' AND t.t_date BETWEEN "' . $start_date . '" AND "' . $end_date.'"');
                    }
                    //all
                    elseif($range=='all'){
                        
                    }
                }
                
                //echo "<pre>"; print_r($where); exit;
                $where = implode(' ', $where);
                $where = trim($where);
                if (startsWith($where, 'AND') || startsWith($where, 'OR')) {
                    if (startsWith($where, 'OR')) {
                        $where = substr($where, 2);
                    } else {
                        $where = substr($where, 3);
                    }
                    $where = 'WHERE ' . $where;
                }
                $query = '
                    SELECT count(t.staff_id) as total_activities, t.sam_id, t.staff_id, t.pipeline_id 
                    FROM tbl_sam_transactions as t
                    JOIN tbl_sam as t2 on t.sam_id = t2.id                               
                    '."$where".'
                    group by t.staff_id
                
                ';
                //echo $query; exit;
                $result = $this->db->query($query)->result_array();
                if($result){
                    //echo "<pre>"; print_r($result);exit;
                    return $result;
                }
                else{
                    return false;
                }
                
            }    
        }
    }
    
    //get data for deals and leads diagram
    public function deals_leads_status_stats($post_data=array(),$default=false)
    {   
        if($default){
            $userid_cond = 1;
            if(!is_admin()){
                $userid_cond = "t.default_deal_owner=".get_staff_user_id();
            }
            //this month
            $beginThisMonth = date('Y-m-01 00:00:00');
            $endThisMonth   = date('Y-m-d 23:59:59');
            //array_push($where, ' AND t.created_at BETWEEN "' . $beginThisMonth . '" AND "' . $endThisMonth.'"');

            $where1 = 'WHERE '.$userid_cond.' AND t.status="open" AND t.created_at BETWEEN "' . $beginThisMonth . '" AND "' . $endThisMonth.'"';
            $where2 = 'WHERE '.$userid_cond.' AND t.status="won" AND t.created_at BETWEEN "' . $beginThisMonth . '" AND "' . $endThisMonth.'"';
            $where3 = 'WHERE '.$userid_cond.' AND t.status="lost" AND t.created_at BETWEEN "' . $beginThisMonth . '" AND "' . $endThisMonth.'"';
            $where4 = 'WHERE '.$userid_cond.' AND t.created_at BETWEEN "' . $beginThisMonth . '" AND "' . $endThisMonth.'"';
            $query = '
                SELECT COUNT(*) as total, SUM(deal_value) as value, "open" as name 
                FROM tbl_sam as t                               
                '."$where1".'
                UNION ALL
                SELECT COUNT(*) as total,SUM(deal_value) as value, "won" as name 
                FROM tbl_sam as t                               
                '."$where2".'
                UNION ALL
                SELECT COUNT(*) as total,SUM(deal_value) as value, "lost" as name 
                FROM tbl_sam as t                               
                '."$where3".'
                UNION ALL
                SELECT COUNT(*) as total,SUM(deal_value) as value, "total" as name 
                FROM tbl_sam as t                               
                '."$where4".'
            
            ';
            //echo $query; exit;
            $result = $this->db->query($query)->result_array();
            if($result){
                //echo "<pre>"; print_r($result);exit;
                return $result;
            }
            else{
                return false;
            }    
        }
        else{
            if(is_array($post_data)){
                $where = [];
                if(isset($post_data['staff_id']) && $post_data['staff_id']!=""){
                        $where = [
                            'AND t.default_deal_owner=' . $this->db->escape_str($post_data['staff_id']),
                        ];
                }
                if(isset($post_data['range'])){
                    $range = $post_data['range'];
                    //today
                    if($range=='today'){
                        $beginOfDay = date('Y-m-d 00:00:00',strtotime('TODAY'));       
                        $endOfDay = date('Y-m-d 23:59:59');       
                        array_push($where, ' AND t.created_at BETWEEN "' . $beginOfDay.'" AND "'.$endOfDay.'"');
                    }
                    //seven days
                    elseif($range=='last_seven_days'){
                        $beginThisWeek = date('Y-m-d 00:00:00', strtotime('-7 DAYS'));
                        $endThisWeek   = date('Y-m-d 23:59:59');
                        array_push($where, ' AND t.created_at BETWEEN "' . $beginThisWeek . '" AND "' . $endThisWeek.'"');
                    }
                    //this week
                    elseif($range=='this_week'){
                        $beginThisWeek = date('Y-m-d 00:00:00', strtotime('monday this week'));
                        $endThisWeek   = date('Y-m-d 23:59:59', strtotime('sunday this week'));
                        array_push($where, ' AND t.created_at BETWEEN "' . $beginThisWeek . '" AND "' . $endThisWeek.'"');
                    }
                    //last week
                    elseif($range=='last_week'){
                        $beginLastWeek = date('Y-m-d 00:00:00', strtotime('monday last week'));
                        $endLastWeek   = date('Y-m-d 23:59:59', strtotime('sunday last week'));
                        array_push($where, ' AND t.created_at BETWEEN "' . $beginLastWeek . '" AND "' . $endLastWeek.'"');
                    }
                    //this month
                    elseif($range=='this_month'){
                        $beginThisMonth = date('Y-m-01 00:00:00');
                        $endThisMonth   = date('Y-m-d 23:59:59');
                        array_push($where, ' AND t.created_at BETWEEN "' . $beginThisMonth . '" AND "' . $endThisMonth.'"');
                    }
                    //last month
                    elseif($range=='last_month'){
                        $beginLastMonth = date('Y-m-01 00:00:00', strtotime('-1 MONTH'));
                        $endLastMonth   = date('Y-m-t', strtotime('-1 MONTH'));
                        array_push($where, ' AND t.created_at BETWEEN "' . $beginLastMonth . '" AND "' . $endLastMonth.'"');
                    }
                    //this year
                    elseif($range=='this_year'){
                        $beginOfDay = date('Y-01-01 00:00:00');
                        $endOfDay   = date('Y-12-31 23:59:59');
                        array_push($where, ' AND t.created_at BETWEEN "' . $beginOfDay . '" AND "' . $endOfDay.'"');
                    }
                    //last year
                    elseif($range=='last_year'){
                        $beginOfDay = date('Y-01-01 00:00:00', strtotime('-1 YEAR'));
                        $endOfDay   = date('Y-12-t 23:59:59', strtotime('-1 YEAR'));
                        array_push($where, ' AND t.created_at BETWEEN "' . $beginOfDay . '" AND "' . $endOfDay.'"');
                    }
                    //search by periods
                    elseif($range=='period' && $post_data['periodfrom']!="" && $post_data['periodto']){
                        $start_date = to_sql_date($post_data['periodfrom']);
                        $end_date   = to_sql_date($post_data['periodto']);
                        array_push($where, ' AND t.created_at BETWEEN "' . $start_date . ' 00:00:00" AND "' . $end_date.' 23:59:59"');
                    }
                    //all
                    elseif($range=='all'){
                        
                    }
                }
                
                //echo "<pre>"; print_r($where); exit;
                $where1='';$where2='';$where3='';$where4='';
                $where = implode(' ', $where);
                $where = trim($where);
                $where1 = 'WHERE status="open" ' . $where;
                $where2 = 'WHERE status="won" ' . $where;
                $where3 = 'WHERE status="lost" ' . $where;
                $where4 = 'WHERE 1 ' . $where;
                $query = '
                    SELECT COUNT(*) as total, SUM(deal_value) as value, "open" as name 
                    FROM tbl_sam as t                               
                    '."$where1".'
                    UNION ALL
                    SELECT COUNT(*) as total,SUM(deal_value) as value, "won" as name 
                    FROM tbl_sam as t                               
                    '."$where2".'
                    UNION ALL
                    SELECT COUNT(*) as total,SUM(deal_value) as value, "lost" as name 
                    FROM tbl_sam as t                               
                    '."$where3".'
                    UNION ALL
                    SELECT COUNT(*) as total,SUM(deal_value) as value, "total" as name 
                    FROM tbl_sam as t                               
                    '."$where4".'
                
                ';
                //echo $query; exit;
                $result = $this->db->query($query)->result_array();
                if($result){
                    //echo "<pre>"; print_r($result);exit;
                    return $result;
                }
                else{
                    return false;
                }
                
            }    
        }
    }
    
    //get proposals
    public function getDealProposals($post_data=array(),$default=false){
        if($default){
            $userid_cond = 1;
            if(!is_admin()){
                $userid_cond = "t.addedfrom=".get_staff_user_id();
            }
            $beginThisMonth = date('Y-m-01 00:00:00');
            $endThisMonth   = date('Y-m-d 23:59:59');    
            $date = 'AND t.datecreated BETWEEN "' . $beginThisMonth . '" AND "' . $endThisMonth.'"';
            //sent proposal condition
            $where1 = 'WHERE '.$userid_cond.' AND t.status=4 ' . $date;
            //accepted proposal condition
            $where2 = 'WHERE '.$userid_cond.' AND t.status=3 ' . $date;         
            $query = '
                SELECT SUM(t.total) as total, "total-sent-amount" as status 
                FROM tbl_sam_proposals as t
                JOIN tbl_sam as t2 on t.rec_id = t2.id                              
                '."$where1".'
                UNION ALL 
                SELECT SUM(t.total) as total, "total-accepted-amount" as status 
                FROM tbl_sam_proposals as t 
                JOIN tbl_sam as t2 on t.rec_id = t2.id                               
                '."$where2".'
                UNION ALL 
                SELECT COUNT(*) as total, "total-sent-proposal" as status 
                FROM tbl_sam_proposals as t
                JOIN tbl_sam as t2 on t.rec_id = t2.id                                
                '."$where1".'
                UNION ALL 
                SELECT COUNT(*) as total, "total-accepted-proposal" as status 
                FROM tbl_sam_proposals as t
                JOIN tbl_sam as t2 on t.rec_id = t2.id                                
                '."$where2".'
                    
            ';
            //echo $query; exit;
            $result = $this->db->query($query)->result_array();
            if($result){
                //echo "<pre>"; print_r($result);exit;
                return $result;
            }
            else{
                return false;
            }
        }
        else{
            if(is_array($post_data)){
                $where = [];
                if(isset($post_data['staff_id']) && $post_data['staff_id']!=""){
                        $where = [
                            'AND t.addedfrom=' . $this->db->escape_str($post_data['staff_id']),
                        ];
                }
                if(isset($post_data['range'])){
                    $range = $post_data['range'];
                    //today
                    if($range=='today'){
                        $beginOfDay = date('Y-m-d 00:00:00',strtotime('TODAY'));       
                        $endOfDay = date('Y-m-d 23:59:59');       
                        array_push($where, ' AND t.datecreated BETWEEN "' . $beginOfDay.'" AND "'.$endOfDay.'"');
                    }
                    //seven days
                    elseif($range=='last_seven_days'){
                        $beginThisWeek = date('Y-m-d 00:00:00', strtotime('-7 DAYS'));
                        $endThisWeek   = date('Y-m-d 23:59:59');
                        array_push($where, ' AND t.datecreated BETWEEN "' . $beginThisWeek . '" AND "' . $endThisWeek.'"');
                    }
                    //this week
                    elseif($range=='this_week'){
                        $beginThisWeek = date('Y-m-d 00:00:00', strtotime('monday this week'));
                        $endThisWeek   = date('Y-m-d 23:59:59', strtotime('sunday this week'));
                        array_push($where, ' AND t.datecreated BETWEEN "' . $beginThisWeek . '" AND "' . $endThisWeek.'"');
                    }
                    //last week
                    elseif($range=='last_week'){
                        $beginLastWeek = date('Y-m-d 00:00:00', strtotime('monday last week'));
                        $endLastWeek   = date('Y-m-d 23:59:59', strtotime('sunday last week'));
                        array_push($where, ' AND t.datecreated BETWEEN "' . $beginLastWeek . '" AND "' . $endLastWeek.'"');
                    }
                    //this month
                    elseif($range=='this_month'){
                        $beginThisMonth = date('Y-m-01 00:00:00');
                        $endThisMonth   = date('Y-m-d 23:59:59');
                        array_push($where, ' AND t.datecreated BETWEEN "' . $beginThisMonth . '" AND "' . $endThisMonth.'"');
                    }
                    //last month
                    elseif($range=='last_month'){
                        $beginLastMonth = date('Y-m-01 00:00:00', strtotime('-1 MONTH'));
                        $endLastMonth   = date('Y-m-t 23:59:59', strtotime('-1 MONTH'));
                        array_push($where, ' AND t.datecreated BETWEEN "' . $beginLastMonth . '" AND "' . $endLastMonth.'"');
                    }
                    //this year
                    elseif($range=='this_year'){
                        $beginOfDay = date('Y-01-01 00:00:00');
                        $endOfDay   = date('Y-12-31 23:59:59');
                        array_push($where, ' AND t.datecreated BETWEEN "' . $beginOfDay . '" AND "' . $endOfDay.'"');
                    }
                    //last year
                    elseif($range=='last_year'){
                        $beginOfDay = date('Y-01-01 00:00:00', strtotime('-1 YEAR'));
                        $endOfDay   = date('Y-12-t 23:59:59', strtotime('-1 YEAR'));
                        array_push($where, ' AND t.datecreated BETWEEN "' . $beginOfDay . '" AND "' . $endOfDay.'"');
                    }
                    //search by periods
                    elseif($range=='period' && $post_data['periodfrom']!="" && $post_data['periodto']){
                        $start_date = to_sql_date($post_data['periodfrom']);
                        $end_date   = to_sql_date($post_data['periodto']);
                        array_push($where, ' AND t.datecreated BETWEEN "' . $start_date . ' 00:00:00" AND "' . $end_date.' 23:59:59"');
                    }
                    //all
                    elseif($range=='all'){
                        
                    }
                }
                
                //echo "<pre>"; print_r($where); exit;
                $where1='';$where2='';
                $where = implode(' ', $where);
                $where = trim($where);
                //sent proposal condition
                $where1 = 'WHERE t.status=4 ' . $where;
                //accepted proposal condition
                $where2 = 'WHERE t.status=3 ' . $where;         
                $query = '
                    SELECT SUM(t.total) as total, "total-sent-amount" as status 
                    FROM tbl_sam_proposals as t 
                    JOIN tbl_sam as t2 on t.rec_id = t2.id                               
                    '."$where1".'
                    UNION ALL 
                    SELECT SUM(t.total) as total, "total-accepted-amount" as status 
                    FROM tbl_sam_proposals as t 
                    JOIN tbl_sam as t2 on t.rec_id = t2.id                               
                    '."$where2".'
                    UNION ALL 
                    SELECT COUNT(*) as total, "total-sent-proposal" as status 
                    FROM tbl_sam_proposals as t
                    JOIN tbl_sam as t2 on t.rec_id = t2.id                                
                    '."$where1".'
                    UNION ALL 
                    SELECT COUNT(*) as total, "total-accepted-proposal" as status 
                    FROM tbl_sam_proposals as t
                    JOIN tbl_sam as t2 on t.rec_id = t2.id                                
                    '."$where2".'
                        
                ';
                //echo $query; exit;
                $result = $this->db->query($query)->result_array();
                if($result){
                    //echo "<pre>"; print_r($result);exit;
                    return $result;
                }
                else{
                    return false;
                }
            
            }      
        }
    } 
    
    public function getTotalDealValue($post_data=array(),$default=false){
        if($default){
            $userid_cond = 1;
            if(!is_admin()){
                $userid_cond = "t.default_deal_owner=".get_staff_user_id();
            }
            $where = [];
            //this month
            $beginThisMonth = date('Y-m-01 00:00:00');
            $endThisMonth   = date('Y-m-d 23:59:59');
            $where = 'where '.$userid_cond.' AND t.created_at BETWEEN "' . $beginThisMonth . '" AND "' . $endThisMonth.'"';
            $query = '
                SELECT SUM(t.deal_value) as total 
                FROM tbl_sam as t                               
                '."$where".'        
            ';
            //echo $query; exit;
            $result = $this->db->query($query)->result_array();
            if($result){
                //echo "<pre>"; print_r($result);exit;
                return $result;
            }
            else{
                return false;
            }
       
        }
        else{
            if(is_array($post_data)){
                $where = [];
                if(isset($post_data['staff_id']) && $post_data['staff_id']!=""){
                        $where = [
                            'AND t.default_deal_owner=' . $this->db->escape_str($post_data['staff_id']),
                        ];
                }
                if(isset($post_data['pipeline_id']) && $post_data['pipeline_id']!=""){
                        array_push($where, ' AND t.pipeline_id=' . $post_data['pipeline_id']);
                }
                if(isset($post_data['range'])){
                    $range = $post_data['range'];
                    //today
                    if($range=='today'){
                        $beginOfDay = date('Y-m-d 00:00:00',strtotime('TODAY'));       
                        $endOfDay = date('Y-m-d 23:59:59');       
                        array_push($where, ' AND t.created_at BETWEEN "' . $beginOfDay.'" AND "'.$endOfDay.'"');
                    }
                    //seven days
                    elseif($range=='last_seven_days'){
                        $beginThisWeek = date('Y-m-d 00:00:00', strtotime('-7 DAYS'));
                        $endThisWeek   = date('Y-m-d 23:59:59');
                        array_push($where, ' AND t.created_at BETWEEN "' . $beginThisWeek . '" AND "' . $endThisWeek.'"');
                    }
                    //this week
                    elseif($range=='this_week'){
                        $beginThisWeek = date('Y-m-d 00:00:00', strtotime('monday this week'));
                        $endThisWeek   = date('Y-m-d 23:59:59', strtotime('sunday this week'));
                        array_push($where, ' AND t.created_at BETWEEN "' . $beginThisWeek . '" AND "' . $endThisWeek.'"');
                    }
                    //last week
                    elseif($range=='last_week'){
                        $beginLastWeek = date('Y-m-d 00:00:00', strtotime('monday last week'));
                        $endLastWeek   = date('Y-m-d 23:59:59', strtotime('sunday last week'));
                        array_push($where, ' AND t.created_at BETWEEN "' . $beginLastWeek . '" AND "' . $endLastWeek.'"');
                    }
                    //this month
                    elseif($range=='this_month'){
                        $beginThisMonth = date('Y-m-01 00:00:00');
                        $endThisMonth   = date('Y-m-d 23:59:59');
                        array_push($where, ' AND t.created_at BETWEEN "' . $beginThisMonth . '" AND "' . $endThisMonth.'"');
                    }
                    //last month
                    elseif($range=='last_month'){
                        $beginLastMonth = date('Y-m-01', strtotime('-1 MONTH'));
                        $endLastMonth   = date('Y-m-t', strtotime('-1 MONTH'));
                        array_push($where, ' AND t.created_at BETWEEN "' . $beginLastMonth . '" AND "' . $endLastMonth.'"');
                    }
                    //this year
                    elseif($range=='this_year'){
                        $beginOfDay = date('Y-01-01 00:00:00');
                        $endOfDay   = date('Y-12-31 23:59:59');
                        array_push($where, ' AND t.created_at BETWEEN "' . $beginOfDay . '" AND "' . $endOfDay.'"');
                    }
                    //last year
                    elseif($range=='last_year'){
                        $beginOfDay = date('Y-01-01 00:00:00', strtotime('-1 YEAR'));
                        $endOfDay   = date('Y-12-t 23:59:59', strtotime('-1 YEAR'));
                        array_push($where, ' AND t.created_at BETWEEN "' . $beginOfDay . '" AND "' . $endOfDay.'"');
                    }
                    //search by periods
                    elseif($range=='period'){
                        $start_date = to_sql_date($post_data['periodfrom']);
                        $end_date   = to_sql_date($post_data['periodto']);
                        array_push($where, ' AND t.created_at BETWEEN "' . $start_date . ' 00:00:00" AND "' . $end_date.' 23:59:59"');
                    }
                    //all
                    elseif($range=='all'){
                        
                    }
                }
                
                //echo "<pre>"; print_r($where); exit;
                $where = implode(' ', $where);
                $where = trim($where);
                if (startsWith($where, 'AND') || startsWith($where, 'OR')) {
                    if (startsWith($where, 'OR')) {
                        $where = substr($where, 2);
                    } else {
                        $where = substr($where, 3);
                    }
                    $where = 'WHERE ' . $where;
                }
                $query = '
                    SELECT SUM(t.deal_value) as total 
                    FROM tbl_sam as t                               
                    '."$where".'        
                ';
                //echo $query; exit;
                $result = $this->db->query($query)->result_array();
                if($result){
                    //echo "<pre>"; print_r($result);exit;
                    return $result;
                }
                else{
                    return false;
                }
                
            }    
        }
        
    }   
    
    public function getSpentTimeOnCustomer($post_data=array(),$default=false){
        if($default){
            $userid_cond = 1;
            if(!is_admin()){
                $userid_cond = "t.staff_id=".get_staff_user_id();
            }
            $beginThisMonth = date('Y-m-01 00:00:00');
            $endThisMonth   = date('Y-m-t 23:59:59');    
            $where = 'WHERE '.$userid_cond.' AND t2.rel_type="customer" AND t.deleted=0 AND t.start_time BETWEEN ' . strtotime($beginThisMonth) . ' AND ' . strtotime($endThisMonth);
            $query = '
                SELECT t.staff_id, t.pipeline_id, t.sam_id, sum(time_spent) as total_time_spent, sum(t2.deal_value) as total_deal_value, t2.rel_id as customer_id 
                FROM tbl_sam_taskstimers as t
                JOIN tbl_sam as t2 on t.sam_id = t2.id
                '."$where".'       
                group by t2.rel_id
            
            ';
            //echo $query; exit;
            $result = $this->db->query($query)->result_array();
            if($result){
                //echo "<pre>"; print_r($result);exit;
                return $result;
            }
            else{
                return false;
            }
        }
        else{
            if(is_array($post_data)){
                $where = [];
                if(isset($post_data['staff_id']) && $post_data['staff_id']!=""){
                        $where = [
                            'AND t.staff_id=' . $this->db->escape_str($post_data['staff_id']),
                        ];
                }
                if(isset($post_data['pipeline_id']) && $post_data['pipeline_id']!=""){
/*                        $where = [
                            'AND t.pipeline_id=' . $this->db->escape_str($post_data['pipeline_id']),
                        ];*/
                }
                if(isset($post_data['range'])){
                    $range = $post_data['range'];
                    //today
                    if($range=='today'){
                        $beginOfDay = strtotime('midnight');
                        $endOfDay   = strtotime('tomorrow', $beginOfDay) - 1;
                        array_push($where, ' AND t.start_time BETWEEN ' . $beginOfDay . ' AND ' . $endOfDay);
                    }
                    //seven days
                    elseif($range=='last_seven_days'){
                        $beginThisWeek = date('Y-m-d', strtotime('-7 DAYS'));
                        $endThisWeek   = date('Y-m-d 23:59:59');
                        array_push($where, ' AND t.start_time BETWEEN ' . strtotime($beginThisWeek) . ' AND ' . strtotime($endThisWeek));
                    }
                    //this week
                    elseif($range=='this_week'){
                        $beginThisWeek = date('Y-m-d', strtotime('monday this week'));
                        $endThisWeek   = date('Y-m-d 23:59:59', strtotime('sunday this week'));
                        array_push($where, ' AND t.start_time BETWEEN ' . strtotime($beginThisWeek) . ' AND ' . strtotime($endThisWeek));
                    }
                    //last week
                    elseif($range=='last_week'){
                        $beginLastWeek = date('Y-m-d', strtotime('monday last week'));
                        $endLastWeek   = date('Y-m-d 23:59:59', strtotime('sunday last week'));
                        array_push($where, ' AND t.start_time BETWEEN ' . strtotime($beginLastWeek) . ' AND ' . strtotime($endLastWeek));
                    }
                    //this month
                    elseif($range=='this_month'){
                        $beginThisMonth = date('Y-m-01');
                        $endThisMonth   = date('Y-m-t 23:59:59');
                        array_push($where, ' AND t.start_time BETWEEN ' . strtotime($beginThisMonth) . ' AND ' . strtotime($endThisMonth));
                    }
                    //last month
                    elseif($range=='last_month'){
                        $beginLastMonth = date('Y-m-01', strtotime('-1 MONTH'));
                        $endLastMonth   = date('Y-m-t 23:59:59', strtotime('-1 MONTH'));
                        array_push($where, ' AND t.start_time BETWEEN ' . strtotime($beginLastMonth) . ' AND ' . strtotime($endLastMonth));
                    }
                    //this year
                    elseif($range=='this_year'){
                        $beginOfDay = date('Y-01-01');
                        $endOfDay   = date('Y-12-t 23:59:59');
                        array_push($where, ' AND t.start_time BETWEEN ' . strtotime($beginOfDay) . ' AND ' . strtotime($endOfDay));
                    }
                    //last year
                    elseif($range=='last_year'){
                        $beginOfDay = date('Y-01-01', strtotime('-1 YEAR'));
                        $endOfDay   = date('Y-12-t 23:59:59', strtotime('-1 YEAR'));
                        array_push($where, ' AND t.start_time BETWEEN ' . strtotime($beginOfDay) . ' AND ' . strtotime($endOfDay));
                    }
                    //search by periods
                    elseif($range=='period'){
                        $start_date = to_sql_date($post_data['periodfrom']);
                        $end_date   = to_sql_date($post_data['periodto']);
                        array_push($where, ' AND t.start_time BETWEEN ' . strtotime($start_date . ' 00:00:00') . ' AND ' . strtotime($end_date . ' 23:59:59'));
                    }
                    //all
                    elseif($range=='all'){
                        
                    }
                }
                
                //echo "<pre>"; print_r($where); exit;
                $where = implode(' ', $where);
                $where = trim($where);
                if (startsWith($where, 'AND') || startsWith($where, 'OR')) {
                    if (startsWith($where, 'OR')) {
                        $where = substr($where, 2);
                    } else {
                        $where = substr($where, 3);
                    }                
                }
                if($where!=''){
                    $where = 'WHERE t.deleted=0 AND t2.rel_type="customer" AND ' . $where;    
                }
                else{
                    $where = 'WHERE t.deleted=0 AND t2.rel_type="customer"';
                }
                $query = '
                    SELECT t.staff_id, t.pipeline_id, t.sam_id, sum(time_spent) as total_time_spent, sum(t2.deal_value) as total_deal_value, t2.rel_id as customer_id 
                    FROM tbl_sam_taskstimers as t
                    JOIN tbl_sam as t2 on t.sam_id = t2.id
                    '."$where".'
                    group by t2.rel_id
                
                ';
                //echo $query; exit;
                $result = $this->db->query($query)->result_array();
                if($result){
                    //echo "<pre>"; print_r($result);exit;
                    return $result;
                }
                else{
                    return false;
                }
                
            }        
        }
    }
    
    public function getAllRemindersOnDashboard($post_data=array(),$default=false){
        if($default){
            $userid_cond = 1;
/*            if(!is_admin()){
                $userid_cond = "t.staff=".get_staff_user_id();
            }*/
            $beginThisMonth = date('Y-m-01 00:00:00');
            $endThisMonth   = date('Y-m-t 23:59:59');    
            $where = 'WHERE '.$userid_cond.' AND t.rel_type="sam" AND t.date BETWEEN "' . $beginThisMonth . '" AND "' . $endThisMonth.'"';
            $query = '
                SELECT t.title, t.description, t.staff, t.creator, t.rel_id as sam_id, t.date, t2.rel_id as customer_id  
                FROM tbl_sam_reminders as t
                JOIN tbl_sam as t2 on t.rel_id = t2.id
                '."$where".'  
                ORDER BY t.date desc     
            
            ';
            //echo $query; exit;
            $result = $this->db->query($query)->result_array();
            if($result){
                //echo "<pre>"; print_r($result);exit;
                return $result;
            }
            else{
                return false;
            }
        }
        else{
            if(is_array($post_data)){
                $where = [];
                if(isset($post_data['staff']) && $post_data['staff']!=""){
                        $where = [
                            'AND t.staff=' . $this->db->escape_str($post_data['staff_id']),
                        ];
                }
                if(isset($post_data['range'])){
                    $range = $post_data['range'];
                    //today
                    if($range=='today'){
                        $beginOfDay = date('Y-m-d 00:00:00',strtotime('TODAY'));       
                        $endOfDay = date('Y-m-d 23:59:59'); 
                        array_push($where, ' AND t.date BETWEEN "' . $beginOfDay . '" AND "' . $endOfDay.'"');
                    }
                    //seven days
                    elseif($range=='last_seven_days'){
                        $beginThisWeek = date('Y-m-d 00:00:00', strtotime('-7 DAYS'));
                        $endThisWeek   = date('Y-m-d 23:59:59');
                        array_push($where, ' AND t.date BETWEEN "' . $beginThisWeek . '" AND "' . $endThisWeek.'"');
                    }
                    //this week
                    elseif($range=='this_week'){
                        $beginThisWeek = date('Y-m-d 00:00:00', strtotime('monday this week'));
                        $endThisWeek   = date('Y-m-d 23:59:59', strtotime('sunday this week'));
                        array_push($where, ' AND t.date BETWEEN "' . $beginThisWeek . '" AND "' . $endThisWeek.'"');
                    }
                    //last week
                    elseif($range=='last_week'){
                        $beginLastWeek = date('Y-m-d 00:00:00', strtotime('monday last week'));
                        $endLastWeek   = date('Y-m-d 23:59:59', strtotime('sunday last week'));
                        array_push($where, ' AND t.date BETWEEN "' . $beginLastWeek . '" AND "' . $endLastWeek.'"');
                    }
                    //this month
                    elseif($range=='this_month'){
                        $beginThisMonth = date('Y-m-01 00:00:00');
                        $endThisMonth   = date('Y-m-t 23:59:59');
                        array_push($where, ' AND t.date BETWEEN "' . $beginThisMonth . '" AND "' . $endThisMonth.'"');
                    }
                    //last month
                    elseif($range=='last_month'){
                        $beginLastMonth = date('Y-m-01 00:00:00', strtotime('-1 MONTH'));
                        $endLastMonth   = date('Y-m-t 23:59:59', strtotime('-1 MONTH'));
                        array_push($where, ' AND t.date BETWEEN "' . $beginLastMonth . '" AND "' . $endLastMonth.'"');
                    }
                    //this year
                    elseif($range=='this_year'){
                        $beginOfDay = date('Y-01-01 00:00:00');
                        $endOfDay   = date('Y-12-t 23:59:59');
                        array_push($where, ' AND t.date BETWEEN "' . $beginOfDay . '" AND "' . $endOfDay.'"');
                    }
                    //last year
                    elseif($range=='last_year'){
                        $beginOfDay = date('Y-01-01 00:00:00', strtotime('-1 YEAR'));
                        $endOfDay   = date('Y-12-t 23:59:59', strtotime('-1 YEAR'));
                        array_push($where, ' AND t.date BETWEEN "' . $beginOfDay . '" AND "' . $endOfDay.'"');
                    }
                    //search by periods
                    elseif($range=='period'){
                        $start_date = to_sql_date($post_data['periodfrom']);
                        $end_date   = to_sql_date($post_data['periodto']);
                        array_push($where, ' AND t.date BETWEEN "' . $start_date . ' 00:00:00' . '" AND "' . $end_date . ' 23:59:59'.'"');
                    }
                    //all
                    elseif($range=='all'){
                        
                    }
                }
                
                //echo "<pre>"; print_r($where); exit;
                $where = implode(' ', $where);
                $where = trim($where);
                if (startsWith($where, 'AND') || startsWith($where, 'OR')) {
                    if (startsWith($where, 'OR')) {
                        $where = substr($where, 2);
                    } else {
                        $where = substr($where, 3);
                    }                
                }
                if($where!=''){
                    $where = 'WHERE t.rel_type="sam" AND ' . $where;    
                }
                else{
                    $where = 'WHERE t.rel_type="sam"';
                }
                $query = '
                    SELECT t.title, t.description, t.staff, t.creator, t.rel_id as sam_id, t.date, t2.rel_id as customer_id 
                    FROM tbl_sam_reminders as t
                    JOIN tbl_sam as t2 on t.rel_id = t2.id
                    '."$where".'
                    ORDER BY t.date desc                 
                
                ';
                //echo $query; exit;
                $result = $this->db->query($query)->result_array();
                if($result){
                    //echo "<pre>"; print_r($result);exit;
                    return $result;
                }
                else{
                    return false;
                }
                
            }        
        }
    }
}