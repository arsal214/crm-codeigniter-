<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>


<link href="<?php echo module_dir_url('school_leads','assets/css/si_lead_filters_style.css'); ?>" rel="stylesheet" />
<div id="wrapper">
	<div class="content">
		<div class="row">
			<div class="col-md-12">


			</div>
		</div>
	</div>
</div>


</body>
</html>

<script>
			  
</script>

