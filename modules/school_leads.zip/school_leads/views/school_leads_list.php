<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>

<div id="wrapper">
	<div class="content">
		<div class="row">
			<div class="col-md-12">

			</div>
		</div>
	</div>
</div>

</body>
</html>
<script>
	
</script>

