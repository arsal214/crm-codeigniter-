<?php 
defined('BASEPATH') or exit('No direct script access allowed'); 
if(isset($invoiceid)){
    $invoice = $this->invoices_model->get($invoiceid); //echo "<pre>"; print_r($invoice); exit;
    $invoice = $invoice[0];
}
?>

<div class="col-md-12">
<?php if(isset($invoice)) {?>
    <div class="row-options tw-text-lg tw-text-neutral-700" style="font-size:1.25em">
        <?php echo "Proposal #: " ?>
        <a href="<?php echo admin_url(SAM_MODULE.'/proposals/#' . $invoice['pro_id']); ?>" target="_blank">
            <?php echo e(format_proposal_number($invoice['pro_id'])); ?>
        </a>
         | <?php echo "Contract #: " ?>
        <a href="<?php echo admin_url(SAM_MODULE.'/contracts/contract/' . $invoice['contract_id'] .'/'.$invoice['sam_id']); ?>" target="_blank">
            <?php echo $invoice['contract_id']; ?>
        </a>
    
    </div>
<?php } ?>
</div>
<div class="col-md-12"> 
    <div class="row"> 
        <div class="col-md-12 small-table-right-col">
            <div id="invoice" class=""></div>
        </div>
    </div>
</div>