<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="col-md-12"> 
    <?php 
    if(isset($proposal) && $proposal!=null) {
        $proposal = $proposal[0];
    ?>
        <div class="row-options" style="font-size:1.25em;font-weight:bold">
           <?php echo "Contract #: " ?>
            <a href="<?php echo admin_url(SAM_MODULE.'/contracts/contract/' . $proposal['contract_id'] .'/'.$proposal['sam_id']); ?>" target="_blank">
                <?php echo $proposal['contract_id']; ?>
            </a>              
        </div>
    <?php } ?>
    <div class="row">
        <div class="col-md-12 small-table-right-col">
            <div id="proposal" class="">
            </div>
        </div>
    </div>
</div>